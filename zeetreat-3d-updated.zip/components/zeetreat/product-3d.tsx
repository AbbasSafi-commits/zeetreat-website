'use client'

import { useRef, useState } from 'react'
import Image from 'next/image'
import { cn } from '@/lib/utils'

const DEPTH = 18
const LAYERS = 13

/**
 * A lightweight, dependency-free 3D product renderer.
 *
 * The real Zeetreat front bottle artwork is used as the visible texture. The
 * image is duplicated through the Z axis to create physical-looking depth,
 * with separate dark/gold side lighting and a rear face. This avoids an
 * AI-redrawn package and keeps the supplied label artwork intact.
 */
export function Product3D({
  className,
  interactive = true,
}: {
  className?: string
  interactive?: boolean
}) {
  const wrapRef = useRef<HTMLDivElement>(null)
  const [rotation, setRotation] = useState({ x: 2, y: -10 })

  function updateRotation(clientX: number, clientY: number) {
    if (!interactive || !wrapRef.current) return
    const rect = wrapRef.current.getBoundingClientRect()
    const px = (clientX - rect.left) / rect.width
    const py = (clientY - rect.top) / rect.height

    setRotation({
      x: 5 + (0.5 - py) * 13,
      y: -10 + (px - 0.5) * 28,
    })
  }

  function handleMouseMove(e: React.MouseEvent<HTMLDivElement>) {
    updateRotation(e.clientX, e.clientY)
  }

  function handleTouchMove(e: React.TouchEvent<HTMLDivElement>) {
    const touch = e.touches[0]
    if (touch) updateRotation(touch.clientX, touch.clientY)
  }

  function resetRotation() {
    setRotation({ x: 2, y: -10 })
  }

  return (
    <div
      ref={wrapRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={resetRotation}
      onTouchMove={handleTouchMove}
      onTouchEnd={resetRotation}
      className={cn(
        'relative flex items-center justify-center [perspective:1400px] [touch-action:none]',
        className,
      )}
      aria-label="Interactive 3D view of the Zeetreat Herbal Hair Oil bottle"
    >
      {/* Ground contact shadow */}
      <div className="pointer-events-none absolute bottom-[3%] left-1/2 h-8 w-[48%] -translate-x-1/2 rounded-[50%] bg-black/35 blur-2xl" />

      {/* Whole bottle rotates in 3D; floating is on a separate nested layer. */}
      <div
        className="relative h-[92%] w-[62%] animate-zt-float [transform-style:preserve-3d]"
        style={{
          transform: `rotateX(${rotation.x}deg) rotateY(${rotation.y}deg)`,
          transition: 'transform 450ms cubic-bezier(.2,.75,.2,1)',
        }}
      >
        <div className="absolute inset-0 [transform-style:preserve-3d]">
          {/* Extruded layers: the supplied artwork stays unchanged on every layer. */}
          {Array.from({ length: LAYERS }, (_, index) => {
            const z = -DEPTH + (index / (LAYERS - 1)) * DEPTH * 2
            const isFront = index === LAYERS - 1
            const isBack = index === 0

            return (
              <div
                key={index}
                className="absolute inset-0 overflow-hidden [backface-visibility:hidden]"
                style={{
                  transform: `translateZ(${z}px)`,
                  filter: isFront
                    ? 'drop-shadow(0 28px 24px rgba(20, 11, 4, .42))'
                    : isBack
                      ? 'brightness(.48) saturate(.75)'
                      : 'brightness(.72) saturate(.8)',
                }}
              >
                <Image
                  src="/zeetreat-bottle-front.png"
                  alt={isFront ? 'Zeetreat Herbal Hair Oil, 200ml bottle' : ''}
                  fill
                  priority={isFront}
                  sizes="(max-width: 768px) 55vw, 24vw"
                  className="object-contain"
                />
              </div>
            )
          })}

          {/* Warm rim light makes the extrusion read as a physical bottle. */}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-y-[5%] right-[8%] w-[13%] rounded-r-[45%] bg-gradient-to-l from-brand-gold/45 via-white/10 to-transparent opacity-70 blur-[3px] [transform:translateZ(20px)]"
          />

          {/* Gloss passes across the real artwork instead of replacing it. */}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-y-[4%] left-[23%] w-[18%] -skew-x-6 rounded-full bg-gradient-to-r from-transparent via-white/25 to-transparent opacity-60 blur-md [transform:translateZ(22px)] animate-zt-shine"
          />
        </div>
      </div>

      <p className="pointer-events-none absolute bottom-0 left-1/2 -translate-x-1/2 whitespace-nowrap text-[9px] font-medium uppercase tracking-[0.2em] text-brand-cream/50 sm:text-[10px]">
        Move to explore
      </p>
    </div>
  )
}
